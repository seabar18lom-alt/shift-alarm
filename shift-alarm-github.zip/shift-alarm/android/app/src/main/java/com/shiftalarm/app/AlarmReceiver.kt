package com.shiftalarm.app

import android.app.*
import android.content.*
import android.os.Build
import android.provider.Settings

class AlarmReceiver:android.content.BroadcastReceiver(){
 override fun onReceive(c:Context,i:Intent){
  Engine.channel(c)
  val title=i.getStringExtra("title")?:"근무 알람";val code=i.getIntExtra("code",0)
  val screen=Intent(c,RingingActivity::class.java).putExtra("title",title).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
  val action=PendingIntent.getActivity(c,code,screen,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
  val builder=Notification.Builder(c,Engine.CHANNEL).setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
   .setContentTitle("교대알람 · $title").setContentText("지금 확인할 업무가 있어요.").setCategory(Notification.CATEGORY_ALARM)
   .setVisibility(Notification.VISIBILITY_PUBLIC).setPriority(Notification.PRIORITY_MAX).setOngoing(true)
   .setContentIntent(action).setFullScreenIntent(action,true).setAutoCancel(false)
  c.getSystemService(NotificationManager::class.java).notify(code,builder.build())
 }
}
class BootReceiver:android.content.BroadcastReceiver(){override fun onReceive(c:Context,i:Intent){Engine.schedule(c)}}
