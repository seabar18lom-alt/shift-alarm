package com.shiftalarm.app

import android.app.*
import android.os.*
import android.content.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.*
import android.view.*
import android.widget.*

class RingingActivity:Activity(){
 private var player:MediaPlayer?=null;private var vibrator:Vibrator?=null
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState)
  setShowWhenLocked(true);setTurnScreenOn(true);window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
  val bg=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setBackgroundColor(Color.rgb(24,44,89));setPadding(32,32,32,32)}
  val h=TextView(this).apply{text="⏰  교대알람";textSize=21f;setTextColor(Color.rgb(174,200,255));gravity=Gravity.CENTER}
  val title=TextView(this).apply{text=intent.getStringExtra("title")?:"근무 알람";textSize=33f;typeface=Typeface.DEFAULT_BOLD;setTextColor(Color.WHITE);gravity=Gravity.CENTER;setPadding(0,30,0,50)}
  val dismiss=Button(this).apply{text="알람 종료";textSize=20f;setOnClickListener{stop();finish()}}
  bg.addView(h);bg.addView(title);bg.addView(dismiss,LinearLayout.LayoutParams(-1,64));setContentView(bg)
  val uri=android.provider.Settings.System.DEFAULT_ALARM_ALERT_URI
  try{player=MediaPlayer.create(this,uri)?.apply{isLooping=true;start()}}catch(_:Exception){}
  try{vibrator=getSystemService(Vibrator::class.java);vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0,500,350),0))}catch(_:Exception){}
 }
 private fun stop(){player?.stop();player?.release();player=null;vibrator?.cancel();getSystemService(NotificationManager::class.java).cancelAll()}
 override fun onDestroy(){stop();super.onDestroy()}
}
